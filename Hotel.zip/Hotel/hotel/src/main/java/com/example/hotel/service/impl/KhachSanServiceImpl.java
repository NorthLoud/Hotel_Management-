package com.example.hotel.service.impl;

import com.example.hotel.entity.KhachSan;
import com.example.hotel.repository.KhachSanRepository;
import com.example.hotel.service.KhachSanService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class KhachSanServiceImpl implements KhachSanService {

    @Autowired
    private KhachSanRepository repository;

    @Override
    public List<KhachSan> getAllKhachSan() {
        return repository.findAll();
    }

    @Override
    public Optional<KhachSan> getKhachSanById(String maKhachSan) {
        return repository.findById(maKhachSan);
    }

    @Override
    @Transactional
    public KhachSan saveKhachSan(KhachSan khachSan) {
        return repository.save(khachSan);
    }

    @Override
    @Transactional
    public KhachSan updateKhachSan(KhachSan khachSan) {
        Optional<KhachSan> existingOpt = repository.findById(khachSan.getMaKhachSan());
        if (existingOpt.isPresent()) {
            KhachSan existing = existingOpt.get();
            existing.setTenKhachSan(khachSan.getTenKhachSan());
            existing.setDiaChi(khachSan.getDiaChi());
            existing.setHinhAnh(khachSan.getHinhAnh());
            existing.setGioiThieu(khachSan.getGioiThieu());
            existing.setTienIch(khachSan.getTienIch());
            // giữ nguyên diemTB
            return repository.save(existing);
        }
        return repository.save(khachSan);
    }


    @Override
    @Transactional
    public void deleteKhachSan(String maKhachSan) {
        repository.deleteById(maKhachSan);
    }


    @Override
    public List<KhachSan> searchByDiaChi(String diaChi) {
        return repository.findByDiaChiContaining(diaChi);
    }


}
