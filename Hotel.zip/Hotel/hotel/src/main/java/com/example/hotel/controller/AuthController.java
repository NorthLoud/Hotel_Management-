package com.example.hotel.controller;

import com.example.hotel.entity.KhachHang;
import com.example.hotel.service.KhachHangService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.Optional;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "*")
public class AuthController {

    @Autowired
    private KhachHangService khachHangService;

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody KhachHang khachHang) {

        if (khachHangService.getKhachHangByTenTaiKhoan(khachHang.getTenTaiKhoan()).isPresent()) {
            return ResponseEntity
                    .badRequest()
                    .body("Tên tài khoản đã tồn tại!");
        }

        if (khachHangService.getKhachHangByEmail(khachHang.getEmail()).isPresent()) {
            return ResponseEntity
                    .badRequest()
                    .body("Email đã tồn tại!");
        }

        if (khachHangService.getKhachHangBySdt(khachHang.getSdt()).isPresent()) {
            return ResponseEntity
                    .badRequest()
                    .body("Số điện thoại đã tồn tại!");
        }

        khachHang.setNgayTao(LocalDateTime.now());
        KhachHang savedKhachHang = khachHangService.saveKhachHang(khachHang);
        return ResponseEntity.ok(savedKhachHang);
    }


    // Đăng nhập cơ bản (theo email + mật khẩu)
    @PostMapping("/login")
    public Optional<KhachHang> login(@RequestParam String email, @RequestParam String matKhau) {
        return khachHangService.getKhachHangByEmailAndMatKhau(email, matKhau);
    }
}
