package com.example.hotel.controller;

import com.example.hotel.entity.DanhGia;
import com.example.hotel.service.DanhGiaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/danhgia")
@CrossOrigin(origins = "*")
public class DanhGiaController {

    @Autowired
    private DanhGiaService danhGiaService;

    @GetMapping
    public List<DanhGia> getAllDanhGia() {
        return danhGiaService.getAllDanhGia();
    }

    @GetMapping("/khachsan/{maKhachSan}")
    public List<DanhGia> getDanhGiaByKhachSan(@PathVariable String maKhachSan) {
        return danhGiaService.getDanhGiaByMaKhachSan(maKhachSan);
    }

    @GetMapping("/count")
    public long countDanhGia() {
        return danhGiaService.getAllDanhGia().size();
    }


    @PostMapping
    public DanhGia createDanhGia(@RequestBody DanhGia danhGia) {
        return danhGiaService.saveDanhGia(danhGia);
    }

    @PutMapping("/{maKhachSan}/{maKhachHang}")
    public DanhGia updateDanhGia(@PathVariable String maKhachSan, @PathVariable String maKhachHang,
                                 @RequestBody DanhGia danhGia) {
        danhGia.setMaKhachSan(maKhachSan);
        danhGia.setMaKhachHang(maKhachHang);
        return danhGiaService.updateDanhGia(danhGia);
    }

    @DeleteMapping("/{maKhachSan}/{maKhachHang}")
    public void deleteDanhGia(@PathVariable String maKhachSan, @PathVariable String maKhachHang) {
        danhGiaService.deleteDanhGia(maKhachSan, maKhachHang);
    }
}
