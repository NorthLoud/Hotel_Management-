package com.example.hotel.service;

import com.example.hotel.entity.HoaDon;

import java.util.List;
import java.util.Optional;

public interface HoaDonService {
    List<HoaDon> getAllHoaDon();
    Optional<HoaDon> getHoaDonById(String maKhachHang, String maPhong);
    List<HoaDon> getHoaDonByMaKhachHang(String maKhachHang);
    List<HoaDon> getHoaDonByMaPhong(String maPhong);
    HoaDon saveHoaDon(HoaDon hoaDon);
    HoaDon updateHoaDon(HoaDon hoaDon);
    void deleteHoaDon(String maKhachHang, String maPhong);
    // --- Thêm ---
    long countHoaDon();
}
