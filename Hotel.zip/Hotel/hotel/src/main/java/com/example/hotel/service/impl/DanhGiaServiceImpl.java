package com.example.hotel.service.impl;

import com.example.hotel.entity.DanhGia;
import com.example.hotel.entity.DanhGiaId;
import com.example.hotel.repository.DanhGiaRepository;
import com.example.hotel.service.DanhGiaService;
import com.example.hotel.service.KhachSanService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DanhGiaServiceImpl implements DanhGiaService {

    @Autowired
    private DanhGiaRepository repository;

    @Override
    public List<DanhGia> getAllDanhGia() {
        return repository.findAll();
    }

    @Override
    public Optional<DanhGia> getDanhGiaById(String maKhachSan, String maKhachHang) {
        return repository.findById(new DanhGiaId(maKhachSan, maKhachHang));
    }

    @Override
    public List<DanhGia> getDanhGiaByMaKhachSan(String maKhachSan) {
        return repository.findByMaKhachSan(maKhachSan);
    }

    @Override
    public List<DanhGia> getDanhGiaByMaKhachHang(String maKhachHang) {
        return repository.findByMaKhachHang(maKhachHang);
    }

    @Override
    public DanhGia saveDanhGia(DanhGia danhGia) {
        DanhGia saved = repository.save(danhGia);
        updateDiemTB(danhGia.getMaKhachSan());  // ✅ Thêm dòng này nếu chưa có
        return saved;
    }

    @Override
    public DanhGia updateDanhGia(DanhGia danhGia) {
        DanhGia updated = repository.save(danhGia);
        updateDiemTB(danhGia.getMaKhachSan());  // ✅ Thêm dòng này nếu chưa có
        return updated;
    }

    @Override
    public void deleteDanhGia(String maKhachSan, String maKhachHang) {
        repository.deleteById(new DanhGiaId(maKhachSan, maKhachHang));
        updateDiemTB(maKhachSan);  // ✅ Thêm dòng này nếu chưa có
    }

    // --- Thêm count ---
    @Override
    public long countDanhGia() {
        return repository.count();
    }

    @Autowired
    private KhachSanService khachSanService;

    private void updateDiemTB(String maKhachSan) {
        // Lấy tất cả đánh giá của khách sạn
        List<DanhGia> danhGias = repository.findByMaKhachSan(maKhachSan);

        // Tính trung bình
        double avg = danhGias.stream()
                .mapToDouble(d -> d.getSoDiem() != null ? d.getSoDiem() : 0)
                .average()
                .orElse(0);

        // Cập nhật KhachSan
        khachSanService.getKhachSanById(maKhachSan).ifPresent(ks -> {
            ks.setDiemTB(avg);
            khachSanService.updateKhachSan(ks);
        });
    }

}
