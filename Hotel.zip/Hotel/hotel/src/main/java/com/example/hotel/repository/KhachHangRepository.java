package com.example.hotel.repository;

import com.example.hotel.entity.KhachHang;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface KhachHangRepository extends JpaRepository<KhachHang, String> {
    Optional<KhachHang> findByEmailAndMatKhau(String email, String matKhau);
    // --- Thêm count ---
    long count();
    Optional<KhachHang> findByTenTaiKhoan(String tenTaiKhoan);
    Optional<KhachHang> findByEmail(String email);
    Optional<KhachHang> findBySdt(String sdt);
}
