package com.example.hotel.repository;

import com.example.hotel.entity.DanhGia;
import com.example.hotel.entity.DanhGiaId;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface DanhGiaRepository extends JpaRepository<DanhGia, DanhGiaId> {
    long count();
    List<DanhGia> findByMaKhachSan(String maKhachSan);
    List<DanhGia> findByMaKhachHang(String maKhachHang);
}

