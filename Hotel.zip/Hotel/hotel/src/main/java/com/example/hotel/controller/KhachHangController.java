package com.example.hotel.controller;

import com.example.hotel.entity.KhachHang;
import com.example.hotel.service.KhachHangService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/khachhang")
@CrossOrigin(origins = "*")
public class KhachHangController {

    @Autowired
    private KhachHangService khachHangService;

    @GetMapping
    public List<KhachHang> getAllKhachHang() {
        return khachHangService.getAllKhachHang();
    }

    @GetMapping("/{maKhachHang}")
    public Optional<KhachHang> getKhachHangById(@PathVariable String maKhachHang) {
        return khachHangService.getKhachHangById(maKhachHang);
    }
    @GetMapping("/count")
    public long countKhachHang() {
        return khachHangService.getAllKhachHang().size();
    }


    @PostMapping
    public KhachHang createKhachHang(@RequestBody KhachHang khachHang) {
        return khachHangService.saveKhachHang(khachHang);
    }

    @PutMapping("/{maKhachHang}")
    public KhachHang updateKhachHang(@PathVariable String maKhachHang, @RequestBody KhachHang khachHang) {
        khachHang.setMaKhachHang(maKhachHang);
        return khachHangService.updateKhachHang(khachHang);
    }

    @DeleteMapping("/{maKhachHang}")
    public void deleteKhachHang(@PathVariable String maKhachHang) {
        khachHangService.deleteKhachHang(maKhachHang);
    }
}
