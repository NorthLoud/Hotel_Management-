package com.example.hotel.service;

import com.example.hotel.entity.Phong;

import java.util.List;
import java.util.Optional;

public interface PhongService {
    List<Phong> getAllPhong();
    Optional<Phong> getPhongById(String maPhong);
    List<Phong> getPhongByMaKhachSan(String maKhachSan);
    List<Phong> getPhongByTrangThai(String trangThai);
    Phong savePhong(Phong phong);
    Phong updatePhong(Phong phong);
    void deletePhong(String maPhong);
    // --- Thêm ---
    long countPhongTheoTrangThai(Phong.TrangThai trangThai);
}
