package com.example.hotel.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Table(name = "KhachHang")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class KhachHang {

    @Id
    @Column(name = "MaKhachHang", length = 20)
    private String maKhachHang;

    @Column(name = "TenTaiKhoan", columnDefinition = "TEXT", nullable = false)
    private String tenTaiKhoan;

    @Column(name = "Email", columnDefinition = "TEXT", nullable = false)
    private String email;

    @Column(name = "MatKhau", length = 200, nullable = false)
    private String matKhau;

    @Column(name = "SDT", length = 20, nullable = false)
    private String sdt;

    @Column(name = "NgayTao", nullable = false)
    private LocalDateTime ngayTao;
}
