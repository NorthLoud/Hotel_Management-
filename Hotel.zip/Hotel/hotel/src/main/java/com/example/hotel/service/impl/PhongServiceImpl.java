package com.example.hotel.service.impl;

import com.example.hotel.entity.Phong;
import com.example.hotel.repository.PhongRepository;
import com.example.hotel.service.PhongService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PhongServiceImpl implements PhongService {

    @Autowired
    private PhongRepository repository;

    @Override
    public List<Phong> getAllPhong() {
        return repository.findAll();
    }

    @Override
    public Optional<Phong> getPhongById(String maPhong) {
        return repository.findById(maPhong);
    }

    @Override
    public List<Phong> getPhongByMaKhachSan(String maKhachSan) {
        return repository.findByKhachSan_MaKhachSan(maKhachSan);
    }

    @Override
    public List<Phong> getPhongByTrangThai(String trangThai) {
        return repository.findByTrangThai(Phong.TrangThai.valueOf(trangThai));
    }


    @Override
    public Phong savePhong(Phong phong) {
        return repository.save(phong);
    }

    @Override
    public Phong updatePhong(Phong phong) {
        return repository.save(phong);
    }

    @Override
    public void deletePhong(String maPhong) {
        repository.deleteById(maPhong);
    }
    // --- Thêm ---
    @Override
    public long countPhongTheoTrangThai(Phong.TrangThai trangThai) {
        return repository.countByTrangThai(trangThai);
    }
}
