package com.example.hotel.controller;

import com.example.hotel.entity.HoaDon;
import com.example.hotel.service.HoaDonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/hoadon")
@CrossOrigin(origins = "*")
public class HoaDonController {

    @Autowired
    private HoaDonService hoaDonService;

    @GetMapping
    public List<HoaDon> getAllHoaDon() {
        return hoaDonService.getAllHoaDon();
    }

    @GetMapping("/{maKhachHang}/{maPhong}")
    public Optional<HoaDon> getHoaDonById(@PathVariable String maKhachHang, @PathVariable String maPhong) {
        return hoaDonService.getHoaDonById(maKhachHang, maPhong);
    }
    @GetMapping("/count")
    public long countHoaDon() {
        return hoaDonService.getAllHoaDon().size();
    }


    @PostMapping
    public HoaDon createHoaDon(@RequestBody HoaDon hoaDon) {
        return hoaDonService.saveHoaDon(hoaDon);
    }

    @PutMapping("/{maKhachHang}/{maPhong}")
    public HoaDon updateHoaDon(@PathVariable String maKhachHang, @PathVariable String maPhong,
                               @RequestBody HoaDon hoaDon) {
        hoaDon.setMaKhachHang(maKhachHang);
        hoaDon.setMaPhong(maPhong);
        return hoaDonService.updateHoaDon(hoaDon);
    }

    @DeleteMapping("/{maKhachHang}/{maPhong}")
    public void deleteHoaDon(@PathVariable String maKhachHang, @PathVariable String maPhong) {
        hoaDonService.deleteHoaDon(maKhachHang, maPhong);
    }
}
