package com.example.hotel.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "Phong")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Phong {
    @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})

    @Id
    @Column(name = "MaPhong", length = 20)
    private String maPhong;

    @ManyToOne
    @JoinColumn(name = "MaKhachSan", nullable = false)
    private KhachSan khachSan;

    @Column(name = "LoaiPhong", columnDefinition = "TEXT", nullable = false)
    private String loaiPhong;

    @Column(name = "HinhAnh", columnDefinition = "TEXT")
    private String hinhAnh;

    @Column(name = "SoNguoi", nullable = false)
    private Integer soNguoi;

    @Column(name = "DienTich")
    private Integer dienTich;

    @Column(name = "TienIch", columnDefinition = "TEXT")
    private String tienIch;

    @Column(name = "GiaPhong", nullable = false)
    private Integer giaPhong;

    @Enumerated(EnumType.STRING)
    @Column(name = "TrangThai", nullable = false)
    private TrangThai trangThai;

    public enum TrangThai {
        Trong, DaThue
    }
    public String getMaKhachSan() {
        return khachSan != null ? khachSan.getMaKhachSan() : null;
    }

}

