package com.example.hotel.service;

import com.example.hotel.entity.KhachHang;

import java.util.List;
import java.util.Optional;

public interface KhachHangService {

    List<KhachHang> getAllKhachHang();
    Optional<KhachHang> getKhachHangById(String maKhachHang);
    KhachHang saveKhachHang(KhachHang khachHang);
    KhachHang updateKhachHang(KhachHang khachHang);
    void deleteKhachHang(String maKhachHang);
    Optional<KhachHang> getKhachHangByEmailAndMatKhau(String email, String matKhau);
    // --- Thêm ---
    long countKhachHang();
    Optional<KhachHang> getKhachHangByTenTaiKhoan(String tenTaiKhoan);
    Optional<KhachHang> getKhachHangByEmail(String email);
    Optional<KhachHang> getKhachHangBySdt(String sdt);

}
