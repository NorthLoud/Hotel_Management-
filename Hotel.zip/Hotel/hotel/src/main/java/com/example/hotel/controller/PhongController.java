package com.example.hotel.controller;

import com.example.hotel.dto.PhongDTO;

import com.example.hotel.entity.KhachSan;
import com.example.hotel.entity.Phong;
import com.example.hotel.repository.KhachSanRepository;
import com.example.hotel.repository.PhongRepository;
import com.example.hotel.service.PhongService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/phong")
@CrossOrigin(origins = "*")
public class PhongController {
    @Autowired
    private PhongRepository phongRepository;

    @Autowired
    private KhachSanRepository khachSanRepository;

    @Autowired
    private PhongService phongService;

    @GetMapping
    public List<Phong> getAllPhong() {
        return phongService.getAllPhong();
    }

    @GetMapping("/{maPhong}")
    public Optional<Phong> getPhongById(@PathVariable String maPhong) {
        return phongService.getPhongById(maPhong);
    }

    @GetMapping("/khachsan/{maKhachSan}")
    public List<Phong> getPhongByMaKhachSan(@PathVariable String maKhachSan) {
        return phongService.getPhongByMaKhachSan(maKhachSan);
    }
    @GetMapping("/trong/count")
    public long countPhongTrong() {
        return phongRepository.countByTrangThai(Phong.TrangThai.Trong);
    }


    @PostMapping
    public Phong createPhong(@RequestBody PhongDTO dto) {
        KhachSan ks = khachSanRepository.findById(dto.getMaKhachSan())
                .orElseThrow(() -> new RuntimeException("Khách sạn không tồn tại!"));

        Phong phong = new Phong();

        // Sinh mã phòng P001-P999, đảm bảo không trùng
        String newMaPhong;
        do {
            int num = 1 + (int)(Math.random() * 999);
            newMaPhong = "P" + String.format("%03d", num);
        } while (phongRepository.existsById(newMaPhong));

        phong.setMaPhong(newMaPhong);
        phong.setDienTich(dto.getDienTich());
        phong.setGiaPhong(dto.getGiaPhong());
        phong.setLoaiPhong(dto.getLoaiPhong());
        phong.setSoNguoi(dto.getSoNguoi());
        phong.setTienIch(dto.getTienIch());
        phong.setTrangThai(dto.getTrangThai());
        phong.setHinhAnh(dto.getHinhAnh());
        phong.setKhachSan(ks);

        return phongRepository.save(phong);
    }

    @PutMapping("/{maPhong}")
    public Phong updatePhong(@PathVariable String maPhong, @RequestBody PhongDTO dto) {
        Phong phong = phongService.getPhongById(maPhong)
                .orElseThrow(() -> new RuntimeException("Phòng không tồn tại!"));

        KhachSan ks = khachSanRepository.findById(dto.getMaKhachSan())
                .orElseThrow(() -> new RuntimeException("Khách sạn không tồn tại!"));

        phong.setMaPhong(maPhong); // <-- quan trọng
        phong.setLoaiPhong(dto.getLoaiPhong());
        phong.setSoNguoi(dto.getSoNguoi());
        phong.setDienTich(dto.getDienTich());
        phong.setTienIch(dto.getTienIch());
        phong.setGiaPhong(dto.getGiaPhong());
        phong.setTrangThai(dto.getTrangThai());
        phong.setHinhAnh(dto.getHinhAnh());
        phong.setKhachSan(ks);

        return phongService.updatePhong(phong);
    }

    @DeleteMapping("/{maPhong}")
    public void deletePhong(@PathVariable String maPhong) {
        phongService.deletePhong(maPhong);
    }
}
