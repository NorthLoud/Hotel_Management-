package com.example.hotel.service.impl;

import com.example.hotel.entity.KhachHang;
import com.example.hotel.repository.KhachHangRepository;
import com.example.hotel.service.KhachHangService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class KhachHangServiceImpl implements KhachHangService {

    @Autowired
    private KhachHangRepository repository;

    @Override
    public List<KhachHang> getAllKhachHang() {
        return repository.findAll();
    }

    @Override
    public Optional<KhachHang> getKhachHangById(String maKhachHang) {
        return repository.findById(maKhachHang);
    }

    @Override
    public KhachHang saveKhachHang(KhachHang khachHang) {
        return repository.save(khachHang);
    }

    @Override
    public KhachHang updateKhachHang(KhachHang khachHang) {
        return repository.save(khachHang);
    }

    @Override
    public void deleteKhachHang(String maKhachHang) {
        repository.deleteById(maKhachHang);
    }

    @Override
    public Optional<KhachHang> getKhachHangByEmailAndMatKhau(String email, String matKhau) {
        return repository.findByEmailAndMatKhau(email, matKhau);
    }
    // --- Thêm ---
    @Override
    public long countKhachHang() {
        return repository.count();
    }
    @Override
    public Optional<KhachHang> getKhachHangByTenTaiKhoan(String tenTaiKhoan) {
        return repository.findByTenTaiKhoan(tenTaiKhoan);
    }

    @Override
    public Optional<KhachHang> getKhachHangByEmail(String email) {
        return repository.findByEmail(email);
    }

    @Override
    public Optional<KhachHang> getKhachHangBySdt(String sdt) {
        return repository.findBySdt(sdt);
    }

}
