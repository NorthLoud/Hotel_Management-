package com.example.hotel.service.impl;

import com.example.hotel.entity.HoaDon;
import com.example.hotel.entity.HoaDonId;
import com.example.hotel.entity.Phong;
import com.example.hotel.repository.HoaDonRepository;
import com.example.hotel.repository.PhongRepository;
import com.example.hotel.service.HoaDonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class HoaDonServiceImpl implements HoaDonService {
    @Autowired
    private PhongRepository phongRepository;

    @Autowired
    private HoaDonRepository repository;

    @Override
    public List<HoaDon> getAllHoaDon() {
        return repository.findAll();
    }

    @Override
    public Optional<HoaDon> getHoaDonById(String maKhachHang, String maPhong) {
        return repository.findById(new HoaDonId(maKhachHang, maPhong));
    }

    @Override
    public List<HoaDon> getHoaDonByMaKhachHang(String maKhachHang) {
        return repository.findByMaKhachHang(maKhachHang);
    }

    @Override
    public List<HoaDon> getHoaDonByMaPhong(String maPhong) {
        return repository.findByMaPhong(maPhong);
    }

    @Override
    public HoaDon saveHoaDon(HoaDon hoaDon) {
        // Lấy thông tin phòng
        var phong = phongRepository.findById(hoaDon.getMaPhong())
                .orElseThrow(() -> new RuntimeException("Không tìm thấy phòng: " + hoaDon.getMaPhong()));

        // Tính số ngày thuê
        long soNgay = java.time.Duration
                .between(hoaDon.getNgayNhanPhong(), hoaDon.getNgayTraPhong())
                .toDays();
        if (soNgay <= 0) soNgay = 1;

        // Tính tổng chi phí
        int tongTien = (int) (soNgay * phong.getGiaPhong());
        hoaDon.setTongChiPhi(tongTien);

        // --- Cập nhật trạng thái phòng tự động ---
        phong.setTrangThai(Phong.TrangThai.DaThue);
        phongRepository.save(phong);

        return repository.save(hoaDon);
    }



    @Override
    public HoaDon updateHoaDon(HoaDon hoaDon) {
        return saveHoaDon(hoaDon); // Tự động tính lại luôn
    }


    @Override
    public void deleteHoaDon(String maKhachHang, String maPhong) {
        // Đặt trạng thái phòng lại Trống
        var phong = phongRepository.findById(maPhong)
                .orElseThrow(() -> new RuntimeException("Không tìm thấy phòng: " + maPhong));
        phong.setTrangThai(Phong.TrangThai.Trong);
        phongRepository.save(phong);

        repository.deleteById(new HoaDonId(maKhachHang, maPhong));
    }

    // --- Thêm ---
    @Override
    public long countHoaDon() {
        return repository.count();
    }
}
