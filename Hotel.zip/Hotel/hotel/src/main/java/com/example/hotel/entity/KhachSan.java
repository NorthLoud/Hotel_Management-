package com.example.hotel.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "KhachSan")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class KhachSan {

    @Id
    @Column(name = "MaKhachSan", length = 36)
    private String maKhachSan;


    @Column(name = "TenKhachSan", columnDefinition = "TEXT", nullable = false)
    private String tenKhachSan;

    @Column(name = "HinhAnh", columnDefinition = "LONGTEXT")
    private String hinhAnh;

    @Column(name = "DiemTB")
    private Double diemTB;

    @Column(name = "DiaChi", columnDefinition = "TEXT", nullable = false)
    private String diaChi;

    @Column(name = "GioiThieu", columnDefinition = "LONGTEXT")
    private String gioiThieu;

    @Column(name = "TienIch", columnDefinition = "TEXT")
    private String tienIch;
}
