package com.example.hotel.controller;

import com.example.hotel.entity.KhachSan;
import com.example.hotel.service.KhachSanService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/khachsan")
@CrossOrigin(origins = "*")
public class KhachSanController {

    @Autowired
    private KhachSanService khachSanService;

    @GetMapping
    public List<KhachSan> getAllKhachSan() {
        return khachSanService.getAllKhachSan();
    }

    @GetMapping("/{maKhachSan}")
    public Optional<KhachSan> getKhachSanById(@PathVariable String maKhachSan) {
        return khachSanService.getKhachSanById(maKhachSan);
    }

    @GetMapping("/search")
    public List<KhachSan> search(@RequestParam String diaChi) {
        return khachSanService.searchByDiaChi(diaChi);
    }

    @PostMapping
    public KhachSan createKhachSan(@RequestBody KhachSan khachSan) {
        // Nếu client không gửi mã, backend sẽ tự sinh
        if (khachSan.getMaKhachSan() == null || khachSan.getMaKhachSan().isEmpty()) {
            // Tạo mã KS + số ngẫu nhiên 3 chữ số
            khachSan.setMaKhachSan("KS" + (int)(100 + Math.random() * 900));
        }
        return khachSanService.saveKhachSan(khachSan);
    }

    @PutMapping("/{maKhachSan}")
    public KhachSan updateKhachSan(@PathVariable String maKhachSan, @RequestBody KhachSan khachSan) {
        khachSan.setMaKhachSan(maKhachSan);
        return khachSanService.updateKhachSan(khachSan);
    }

    @DeleteMapping("/{maKhachSan}")
    public void deleteKhachSan(@PathVariable String maKhachSan) {
        khachSanService.deleteKhachSan(maKhachSan);
    }
}
