package com.example.hotel.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Table(name = "HoaDon")
@IdClass(HoaDonId.class)
@Data
@NoArgsConstructor
@AllArgsConstructor
public class HoaDon {

    @Id
    @Column(name = "MaKhachHang", length = 20)
    private String maKhachHang;

    @Id
    @Column(name = "MaPhong", length = 20)
    private String maPhong;

    @Column(name = "TenKhachHang", columnDefinition = "TEXT", nullable = false)
    private String tenKhachHang;

    @Column(name = "NgayNhanPhong", nullable = false)
    private LocalDateTime ngayNhanPhong;

    @Column(name = "NgayTraPhong", nullable = false)
    private LocalDateTime ngayTraPhong;

    @Column(name = "TongChiPhi", nullable = false)
    private Integer tongChiPhi;

    @Column(name = "Email", columnDefinition = "TEXT", nullable = false)
    private String email;

    @Column(name = "SDT", length = 20, nullable = false)
    private String sdt;
}

