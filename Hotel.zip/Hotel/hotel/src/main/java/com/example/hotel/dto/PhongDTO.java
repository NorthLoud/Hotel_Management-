package com.example.hotel.dto;

import com.example.hotel.entity.Phong;

public class PhongDTO {

    private String maPhong;
    private String maKhachSan; // để nhận Id KhachSan từ client
    private String loaiPhong;
    private Integer soNguoi;
    private Integer dienTich;
    private String tienIch;
    private Integer giaPhong;
    private Phong.TrangThai trangThai;
    private String hinhAnh; // base64

    // --- Getter & Setter ---
    public String getMaPhong() {
        return maPhong;
    }

    public void setMaPhong(String maPhong) {
        this.maPhong = maPhong;
    }

    public String getMaKhachSan() {
        return maKhachSan;
    }

    public void setMaKhachSan(String maKhachSan) {
        this.maKhachSan = maKhachSan;
    }

    public String getLoaiPhong() {
        return loaiPhong;
    }

    public void setLoaiPhong(String loaiPhong) {
        this.loaiPhong = loaiPhong;
    }

    public Integer getSoNguoi() {
        return soNguoi;
    }

    public void setSoNguoi(Integer soNguoi) {
        this.soNguoi = soNguoi;
    }

    public Integer getDienTich() {
        return dienTich;
    }

    public void setDienTich(Integer dienTich) {
        this.dienTich = dienTich;
    }

    public String getTienIch() {
        return tienIch;
    }

    public void setTienIch(String tienIch) {
        this.tienIch = tienIch;
    }

    public Integer getGiaPhong() {
        return giaPhong;
    }

    public void setGiaPhong(Integer giaPhong) {
        this.giaPhong = giaPhong;
    }

    public Phong.TrangThai getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(Phong.TrangThai trangThai) {
        this.trangThai = trangThai;
    }

    public String getHinhAnh() {
        return hinhAnh;
    }

    public void setHinhAnh(String hinhAnh) {
        this.hinhAnh = hinhAnh;
    }
}

