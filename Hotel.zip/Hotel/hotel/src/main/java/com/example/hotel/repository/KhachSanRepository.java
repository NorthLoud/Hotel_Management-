package com.example.hotel.repository;

import com.example.hotel.entity.KhachSan;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface KhachSanRepository extends JpaRepository<KhachSan, String> {
    // Thêm các phương thức truy vấn tùy ý nếu muốn
    List<KhachSan> findByDiaChiContaining(String keyword);

}
