package com.example.hotel.repository;

import com.example.hotel.entity.HoaDon;
import com.example.hotel.entity.HoaDonId;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface HoaDonRepository extends JpaRepository<HoaDon, HoaDonId> {
    List<HoaDon> findByMaKhachHang(String maKhachHang);
    List<HoaDon> findByMaPhong(String maPhong);
    // --- Thêm count ---
    long count();
}
