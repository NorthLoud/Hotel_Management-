package com.example.hotel.repository;

import com.example.hotel.entity.Phong;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PhongRepository extends JpaRepository<Phong, String> {
    List<Phong> findByKhachSan_MaKhachSan(String maKhachSan);
    List<Phong> findByTrangThai(Phong.TrangThai trangThai);
    // --- Thêm count phòng theo trạng thái ---
    long countByTrangThai(Phong.TrangThai trangThai);
}
