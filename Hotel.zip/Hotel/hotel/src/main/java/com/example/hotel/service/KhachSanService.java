package com.example.hotel.service;

import com.example.hotel.entity.KhachSan;

import java.util.List;
import java.util.Optional;

public interface KhachSanService {
    List<KhachSan> getAllKhachSan();
    Optional<KhachSan> getKhachSanById(String maKhachSan);
    KhachSan saveKhachSan(KhachSan khachSan);
    KhachSan updateKhachSan(KhachSan khachSan);
    void deleteKhachSan(String maKhachSan);
    List<KhachSan> searchByDiaChi(String diaChi);
}
