package com.example.hotel.service;

import com.example.hotel.entity.DanhGia;

import java.util.List;
import java.util.Optional;

public interface DanhGiaService {
    List<DanhGia> getAllDanhGia();
    Optional<DanhGia> getDanhGiaById(String maKhachSan, String maKhachHang);
    List<DanhGia> getDanhGiaByMaKhachSan(String maKhachSan);
    List<DanhGia> getDanhGiaByMaKhachHang(String maKhachHang);
    DanhGia saveDanhGia(DanhGia danhGia);
    DanhGia updateDanhGia(DanhGia danhGia);
    void deleteDanhGia(String maKhachSan, String maKhachHang);
    long countDanhGia();
}
