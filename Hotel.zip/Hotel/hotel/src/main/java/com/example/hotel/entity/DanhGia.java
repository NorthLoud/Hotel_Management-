package com.example.hotel.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "DanhGia")
@IdClass(DanhGiaId.class)
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DanhGia {

    @Id
    @Column(name = "MaKhachSan", length = 20)
    private String maKhachSan;

    @Id
    @Column(name = "MaKhachHang", length = 20)
    private String maKhachHang;

    @Column(name = "NoiDung", columnDefinition = "LONGTEXT")
    private String noiDung;

    @Column(name = "SoDiem")
    private Double soDiem;
}
